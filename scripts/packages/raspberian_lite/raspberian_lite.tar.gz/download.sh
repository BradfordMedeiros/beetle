#!/usr/bin/env bash

download https://downloads.raspberrypi.org/NOOBS_lite_latest